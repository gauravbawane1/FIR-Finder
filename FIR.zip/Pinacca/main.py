import os
import tabula
import pdfplumber
import re
from fastapi import FastAPI, File, UploadFile, Form
from fastapi.responses import FileResponse
from sentence_transformers import SentenceTransformer, util
import torch
import pandas as pd
import PyPDF2
from tempfile import NamedTemporaryFile

app = FastAPI()

# Define a dictionary mapping non-English characters to their English equivalents
translation_dict = {
    "०": "0",
    "१": "1",
    "२": "2",
    "३": "3",
    "४": "4",
    "५": "5",
    "६": "6",
    "७": "7",
    "८": "8",
    "९": "9",
}

def translate_to_english(text):
    if isinstance(text, str):
        translated_text = ''.join(translation_dict.get(char, char) for char in text)
        return translated_text
    else:
        return text

def extract_section_values(pdf_path):
    tables = tabula.read_pdf(pdf_path, pages='all', silent=True)
    section_values = []
    for table in tables:
        for index, row in table.iterrows():
            section_value = row.get('Sections (कलम)')
            if section_value:
                translated_section = translate_to_english(section_value)
                section_values.append(translated_section)
    return section_values

def extract_sections_from_pdf(pdf_path):
    section_dict = {}
    with pdfplumber.open(pdf_path) as pdf:
        for page in pdf.pages:
            text = page.extract_text()
            pattern = r'Section (\d+[A-Z]*[A-Z]*)\. (.*)'
            matches = re.findall(pattern, text)
            section_dict.update({match[0]: match[1] for match in matches})
    return section_dict

def extract_first_information_contents(pdf_path):
    with open(pdf_path, 'rb') as file:
        reader = PyPDF2.PdfReader(file)
        content = ""
        for page in reader.pages:
            text = page.extract_text()
            if "First Information contents" in text:
                start_index = text.find("First Information contents")
                content = text[start_index:]
                break
    return content

# Load section dictionary from the second PDF
section_dict_path = 'ipc_sections_ecourts_pta_1.pdf'
section_dict = extract_sections_from_pdf(section_dict_path)

# Directory containing the PDF files
pdf_directory = 'FIR'

# Extract content from the PDF files
# Extract content from the PDF files
data = {}
for filename in os.listdir(pdf_directory):
    if filename.endswith('.pdf'):
        pdf_path = os.path.join(pdf_directory, filename)
        print(f"Processing file: {filename}")
        content = extract_first_information_contents(pdf_path)
        section_values = extract_section_values(pdf_path)
        if section_values:
            for section_value in section_values:
                if section_value in section_dict:
                    category_value = section_dict[section_value]
                    if filename not in data:
                        data[filename] = {'content': content, 'sections': [section_value], 'categories': [category_value]}
                    else:
                        data[filename]['sections'].append(section_value)
                        data[filename]['categories'].append(category_value)
                else:
                    if filename not in data:
                        data[filename] = {'content': content, 'sections': [section_value], 'categories': ["Category: Not found"]}
                    else:
                        data[filename]['sections'].append(section_value)
                        data[filename]['categories'].append("Category: Not found")
        else:
            if filename not in data:
                data[filename] = {'content': content, 'sections': ["No sections found"], 'categories': ["Category: Not found"]}
            else:
                data[filename]['sections'].append("No sections found")
                data[filename]['categories'].append("Category: Not found")

# Convert the extracted data to a DataFrame
df = pd.DataFrame(data.values(), index=data.keys())

# Initialize SBERT model
model = SentenceTransformer('sentence-transformers/multi-qa-mpnet-base-cos-v1')
embeddings = model.encode(df['content'].tolist(), convert_to_tensor=True)
filenames = df.index.tolist()

def find_top_similar_files(query_content, top_k=5):
    query_embedding = model.encode(query_content, convert_to_tensor=True)
    cos_scores = util.pytorch_cos_sim(query_embedding, embeddings)[0]
    top_results = torch.topk(cos_scores, k=top_k)
    top_files = [(filenames[idx.item()], df['sections'][idx.item()], df['categories'][idx.item()], cos_scores[idx.item()].item()) for idx in top_results[1]]
    return top_files


@app.post("/upload/")
async def upload_pdf(file: UploadFile = File(...)):
    temp_file = NamedTemporaryFile(delete=False)
    temp_file.write(await file.read())
    temp_file.close()

    pdf_path = temp_file.name
    content = extract_first_information_contents(pdf_path)
    similar_files = find_top_similar_files(content)

    results_df = pd.DataFrame(similar_files, columns=['Filename', 'Section', 'Category', 'Score'])

    results_path = 'results.xlsx'
    with pd.ExcelWriter(results_path) as writer:
        results_df.to_excel(writer, index=False)

    return FileResponse(results_path, media_type='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet', filename='results.xlsx')

@app.get("/check_result")
async def check_result():
    # Placeholder implementation to simulate result availability
    return {"result_ready": True}

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)
