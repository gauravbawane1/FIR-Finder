Backend Documentation
Overview
The backend of our application is responsible for processing uploaded PDF files, extracting relevant information, and finding similar sections within those files. It consists of a FastAPI server that utilizes various libraries for PDF parsing, text extraction, and similarity calculations.

Features
Extracts content from uploaded PDF files.
Identifies sections within the PDFs.
Utilizes a pre-trained Sentence Transformer model to find similar sections.
Generates an Excel file containing the top similar sections.\


Requirements
To run the code, you need to install the following dependencies:
fastapi==0.70.0
pdfplumber==0.5.29
tabula-py==2.3.0
sentence-transformers==2.1.0
torch==1.10.0
pandas==1.3.3
PyPDF2==1.26.0
uvicorn==0.15.0


You can install these dependencies using the provided requirements.txt file.
Installation
Navigate to the project directory.
Install the dependencies using the following command:

pip install -r requirements.txt


Usage
Start the FastAPI server by running the following command in a terminal:
uvicorn main:app --reload

"""After running the command uvicorn main:app --reload, please allow at least 10 minutes for the server to load all the necessary folders and create embeddings. This initial setup time is required for the backend to process and index the PDF files effectively.

During this initialization period, the server will be processing the PDF files, extracting content, and generating embeddings for similarity calculations. Once this process is complete, the server will be ready to accept requests from the frontend interface.

Thank you for your patience!"""

The server will start running on http://localhost:8000.


Open another terminal to start the Streamlit app by running the following command:
streamlit run app.py

The app will open in your default web browser.
Upload a PDF file using the provided interface.
Click on the "Process File" button to initiate processing.
Once processing is complete, the similar sections will be displayed below.

Backend Code Explanation
The backend code consists of a FastAPI application defined in main.py.
It utilizes functions to extract content and section information from PDF files.
A pre-trained Sentence Transformer model is used to calculate the similarity between sections.
The results are saved in an Excel file and returned to the frontend for display.


Frontend Documentation
Overview
The frontend of our application provides a user-friendly interface for uploading PDF files, initiating processing, and displaying results. It is built using Streamlit, a Python library for creating interactive web applications.

Features
Allows users to upload PDF files.
Provides a button to initiate processing.
Displays the top similar sections from the processed PDF.


Frontend Code Explanation
The frontend code is written in frontend.py using Streamlit.
It provides a simple interface for users to upload files and view results.
Requests library is used to communicate with the backend server.
Results are displayed in a tabular format for easy interpretation.



