import streamlit as st
import requests
import pandas as pd
# Streamlit app title
st.title("PDF Section Extractor and Similarity Finder")

# Upload a PDF file
uploaded_file = st.file_uploader("Upload a PDF file", type="pdf")

# Function to check if the results are ready
def check_result():
    try:
        response = requests.get("http://localhost:8000/check_result")
        if response.status_code == 200:
            result_data = response.json()
            return result_data.get("result_ready", False)
        else:
            return False
    except Exception as e:
        print(f"Error checking result: {e}")
        return False

# Function to fetch and display the results
def fetch_and_display_results():
    try:
        response = requests.post("http://localhost:8000/upload/", files={"file": uploaded_file.getvalue()})
        if response.status_code == 200:
            st.success("File processed successfully!")
            st.info("Fetching results...")
            # Download the results file
            with open("results.xlsx", "wb") as f:
                f.write(response.content)
            # Read results from Excel file
            df = pd.read_excel("results.xlsx")
            # Display the results
            st.write(df)
            st.info("Results Fetched")
        else:
            st.error("Failed to process file")
    except Exception as e:
        st.error(f"Error processing file: {e}")

# Display results if the file is uploaded and results are ready
if uploaded_file:
    if st.button("Process File"):
        if check_result():
            fetch_and_display_results()
        else:
            st.warning("Results are not ready yet. Please wait and try again later.")
